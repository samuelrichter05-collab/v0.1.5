# Base Defender v0.1.5

Die HTML-Datei direkt im Browser öffnen. Im ZIP heißt sie index.html. Auf dem Handy im Querformat spielen.

- Jede Kaserne hält maximal fünf lebende Einheiten gleichzeitig. Zwei Kasernen erlauben zehn Einheiten. Solange Plätze frei sind, entsteht alle fünf Sekunden eine Einheit. Nach einem Verlust aus einer vollen Kaserne startet eine neue Wartezeit von fünf Sekunden. Mehrere Verluste werden nacheinander ersetzt. Einheiten bleiben ihrem Bauplatz zugeordnet, auch bei Zerstörung und Neubau der Kaserne.
- Nahkämpfer und gegnerische Bogenschützen verfolgen das nächstgelegene lebende Ziel: Spieler, Gebäude, verbündete Einheiten oder Basis. Die Entfernung wird zwischen den Mittelpunkten gemessen und laufend neu geprüft. Tote Einheiten greifen nicht mehr an; zerstörte Kasernen produzieren nicht mehr.
- Kompaktes Bau- und Upgrade-Menü am rechten Rand mit Name und Preis. Nach der Auswahl verschwindet das Baumenü, damit alle Bauplätze frei sichtbar sind. Erneutes Tippen auf BAUEN bricht das Platzieren ab.
- Die Änderungen aus v0.1.4 bleiben enthalten, unter anderem 20 Sekunden Respawn und dezente Trefferanimationen.

Validierung: 45 automatisierte Prüfungen bestanden, darunter Ersatzproduktion nach echten Nahkampfverlusten bei zwei Kasernen, Zielwechsel, Touch-Eingaben, Rotation und Respawn. Browserdarstellung in Chrome bei 844×390 und 568×320 kontrolliert, ohne JavaScript-Fehler. Ein Test auf einem echten iPhone steht noch aus.
